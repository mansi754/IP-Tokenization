from algosdk.v2client import algod
from algosdk import account, mnemonic
from algosdk import transaction
from algosdk.atomic_transaction_composer import *
from algosdk.abi import *
import json
import os

# Load the contract
with open("smart_contracts/ip_tokens/contract.py", "r") as f:
    contract_source = f.read()

# Initialize algod client
algod_address = "http://localhost:4001"
algod_token = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
algod_client = algod.AlgodClient(algod_token, algod_address)

# Get suggested parameters
params = algod_client.suggested_params()

# Create a new account for deployment
private_key, address = account.generate_account()
print(f"Created new account: {address}")

# Fund the account (in localnet)
sp = algod_client.suggested_params()
genesis_address = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAY5HFKQ"
txn = transaction.PaymentTxn(
    sender=genesis_address,
    sp=sp,
    receiver=address,
    amt=1000000000  # 1 ALGO
)
signed_txn = txn.sign("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
txid = algod_client.send_transaction(signed_txn)
print(f"Funded account with transaction: {txid}")

# Compile the contract
response = algod_client.compile(contract_source)
contract = response["result"]
print(f"Contract compiled successfully")

# Create the application
app_args = []
on_complete = transaction.OnComplete.NoOpOC.real
global_schema = transaction.StateSchema(num_uints=2, num_byte_slices=1)
local_schema = transaction.StateSchema(num_uints=0, num_byte_slices=0)

# Create the application creation transaction
create_txn = transaction.ApplicationCreateTxn(
    address,
    params,
    on_complete,
    contract,
    app_args,
    global_schema,
    local_schema,
)

# Sign and submit the transaction
signed_txn = create_txn.sign(private_key)
tx_id = algod_client.send_transaction(signed_txn)
print(f"Submitted transaction {tx_id}")

# Wait for confirmation
try:
    transaction_response = transaction.wait_for_confirmation(algod_client, tx_id, 4)
    print(f"Transaction confirmed in round {transaction_response['confirmed-round']}")
    app_id = transaction_response["application-index"]
    print(f"Created new app-id: {app_id}")
except Exception as e:
    print(f"Error: {e}") 
